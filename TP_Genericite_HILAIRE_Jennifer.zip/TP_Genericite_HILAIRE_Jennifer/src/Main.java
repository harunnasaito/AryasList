import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

// ========== ÉTAPE 7 : INTERFACE EMPRUNTABLE ==========

interface Empruntable {
    void emprunter();
}

// ========== ÉTAPE 1 : HIÉRARCHIE DE CLASSES ==========

abstract class Media {
    private String titre;
    private int anneePublication;
    private boolean estEmprunte;

    public Media() {
        this.titre = "";
        this.anneePublication = 0;
        this.estEmprunte = false;
    }

    public Media(String titre, int anneePublication) {
        this.titre = titre;
        this.anneePublication = anneePublication;
        this.estEmprunte = false;
    }

    public String getTitre() {
        return titre;
    }

    public int getAnneePublication() {
        return anneePublication;
    }

    public boolean isEstEmprunte() {
        return estEmprunte;
    }

    protected void setEstEmprunte(boolean estEmprunte) {
        this.estEmprunte = estEmprunte;
    }

    public abstract String getDescription();

    // ÉTAPE 7 : Méthode afficherDetails() non abstraite
    public void afficherDetails() {
        System.out.println("=== Détails du média ===");
        System.out.println("Titre: " + titre);
        System.out.println("Année: " + anneePublication);
        System.out.println("Description: " + getDescription());
        System.out.println("État: " + (estEmprunte ? "Emprunté" : "Disponible"));
        System.out.println("========================");
    }

    @Override
    public String toString() {
        return titre + " (" + anneePublication + ")";
    }
}

class Livre extends Media implements Empruntable {
    private String auteur;
    private int nbPages;

    public Livre(String titre, int anneePublication, String auteur, int nbPages) {
        super(titre, anneePublication);
        this.auteur = auteur;
        this.nbPages = nbPages;
    }

    public String getAuteur() {
        return auteur;
    }

    public int getNbPages() {
        return nbPages;
    }

    @Override
    public String getDescription() {
        return "Livre de " + auteur + ", " + nbPages + " pages.";
    }

    // ÉTAPE 7 : Implémentation de Empruntable
    @Override
    public void emprunter() {
        if (isEstEmprunte()) {
            System.out.println(" Le livre '" + getTitre() + "' est déjà emprunté.");
        } else {
            setEstEmprunte(true);
            System.out.println(" Livre '" + getTitre() + "' emprunté avec succès!");
        }
    }
}

class CD extends Media implements Empruntable {
    private String artiste;
    private int duree;

    public CD(String titre, int anneePublication, String artiste, int duree) {
        super(titre, anneePublication);
        this.artiste = artiste;
        this.duree = duree;
    }

    public String getArtiste() {
        return artiste;
    }

    public int getDuree() {
        return duree;
    }

    @Override
    public String getDescription() {
        return "CD de " + artiste + ", durée : " + duree + " min.";
    }

    // ÉTAPE 7 : Implémentation de Empruntable
    @Override
    public void emprunter() {
        if (isEstEmprunte()) {
            System.out.println(" Le CD '" + getTitre() + "' est déjà emprunté.");
        } else {
            setEstEmprunte(true);
            System.out.println(" CD '" + getTitre() + "' emprunté avec succès!");
        }
    }
}

// ========== ÉTAPE 2 : CLASSE MEMBRE ==========

class Membre {
    private String nom;
    private int id;
    private List<Media> mediasEmpruntes;

    public Membre(String nom, int id) {
        this.nom = nom;
        this.id = id;
        this.mediasEmpruntes = new ArrayList<>();
    }

    public String getNom() {
        return nom;
    }

    public int getId() {
        return id;
    }

    public List<Media> getMediasEmpruntes() {
        return mediasEmpruntes;
    }

    public void emprunterMedia(Media media) {
        mediasEmpruntes.add(media);
    }

    @Override
    public String toString() {
        return "Membre {nom=" + nom + ", id=" + id + "}";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Membre membre = (Membre) obj;
        return id == membre.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}

// ========== CLASSE PRINCIPALE AVEC TOUTES LES MÉTHODES ==========

