import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class BibliothequeSystem {

    // ═══════════════════════════════════════════════════════════
    //                    MÉTHODES GÉNÉRIQUES
    // ═══════════════════════════════════════════════════════════

    public static <T> void afficherListe(List<T> liste) {
        liste.forEach(element -> System.out.println("  • " + element));
    }

    public static <T> List<T> filtrer(List<T> liste, Predicate<T> critere) {
        return liste.stream()
                .filter(critere)
                .collect(Collectors.toList());
    }

    public static <T> void copierCollection(Collection<T> source, Collection<T> destination) {
        destination.addAll(source);
    }

    public static Set<Media> obtenirMediasEmpruntes(Map<Membre, List<Media>> emprunts) {
        return emprunts.values().stream()
                .flatMap(List::stream)
                .collect(Collectors.toSet());
    }

    // ═══════════════════════════════════════════════════════════
    //                    AFFICHAGE STYLISÉ
    // ═══════════════════════════════════════════════════════════

    private static void separateur() {
        System.out.println("\n" + "─".repeat(70));
    }

    private static void titre(String texte) {
        System.out.println("\n╔" + "═".repeat(68) + "╗");
        System.out.printf("║  %-64s  ║%n", texte);
        System.out.println("╚" + "═".repeat(68) + "╝");
    }

    private static void sousTitre(String texte) {
        System.out.println("\n┌─ " + texte + " " + "─".repeat(Math.max(0, 65 - texte.length())));
    }

    // ═══════════════════════════════════════════════════════════
    //                    PROGRAMME PRINCIPAL
    // ═══════════════════════════════════════════════════════════

    public static void main(String[] args) {

        // ───────── Initialisation des données ─────────

        List<Media> medias = new ArrayList<>(Arrays.asList(
                new Livre("1984", 1949, "George Orwell", 328),
                new Livre("Le Petit Prince", 2000, "Antoine de Saint-Exupéry", 96),
                new Livre("Harry Potter", 2015, "J.K. Rowling", 450),
                new CD("Thriller", 1982, "Michael Jackson", 42),
                new CD("21", 2011, "Adele", 48),
                new CD("Divide", 2017, "Ed Sheeran", 46)
        ));

        Set<Membre> membres = new HashSet<>(Arrays.asList(
                new Membre("Jenni", 1),
                new Membre("Hawa", 2),
                new Membre("Nirmala", 3),
                new Membre("Sofia", 4),
                new Membre("Feyza", 5),
                new Membre("Malika", 6)
        ));

        Membre jenni = membres.stream().filter(m -> m.getNom().equals("Jenni")).findFirst().get();
        Membre hawa = membres.stream().filter(m -> m.getNom().equals("Hawa")).findFirst().get();
        Membre nirmala = membres.stream().filter(m -> m.getNom().equals("Nirmala")).findFirst().get();
        Membre sofia = membres.stream().filter(m -> m.getNom().equals("Sofia")).findFirst().get();
        Membre feyza = membres.stream().filter(m -> m.getNom().equals("Feyza")).findFirst().get();
        Membre malika = membres.stream().filter(m -> m.getNom().equals("Malika")).findFirst().get();

        // ───────── Gestion des emprunts ─────────

        jenni.emprunterMedia(medias.get(0));
        jenni.emprunterMedia(medias.get(3));
        hawa.emprunterMedia(medias.get(2));
        nirmala.emprunterMedia(medias.get(1));
        nirmala.emprunterMedia(medias.get(4));
        sofia.emprunterMedia(medias.get(5));
        feyza.emprunterMedia(medias.get(0));
        malika.emprunterMedia(medias.get(3));

        Map<Membre, List<Media>> emprunts = new HashMap<>();
        emprunts.put(jenni, jenni.getMediasEmpruntes());
        emprunts.put(hawa, hawa.getMediasEmpruntes());
        emprunts.put(nirmala, nirmala.getMediasEmpruntes());
        emprunts.put(sofia, sofia.getMediasEmpruntes());
        emprunts.put(feyza, feyza.getMediasEmpruntes());
        emprunts.put(malika, malika.getMediasEmpruntes());

        // ═══════════════════════════════════════════════════════════
        //                    AFFICHAGE INITIAL
        // ═══════════════════════════════════════════════════════════

        titre("SYSTÈME DE GESTION DE BIBLIOTHÈQUE");

        sousTitre("Catalogue des Médias");
        afficherListe(medias);

        sousTitre("Membres Inscrits");
        membres.forEach(m -> System.out.println("  " + m));

        sousTitre("Emprunts en Cours");
        emprunts.forEach((membre, mediasList) -> {
            System.out.println("\n  " + membre.getNom() + " :");
            mediasList.forEach(m -> System.out.println("     > " + m.getTitre() + " - " + m.getDescription()));
        });

        // ═══════════════════════════════════════════════════════════
        //                    FILTRAGE DES DONNÉES
        // ═══════════════════════════════════════════════════════════

        titre("RECHERCHES ET FILTRES");

        sousTitre("Médias récents (après 2010)");
        afficherListe(filtrer(medias, m -> m.getAnneePublication() > 2010));

        sousTitre("Membres dont le nom commence par 'N'");
        afficherListe(filtrer(new ArrayList<>(membres), m -> m.getNom().startsWith("N")));

        sousTitre("Catalogue des Livres");
        afficherListe(filtrer(medias, m -> m instanceof Livre));

        // ═══════════════════════════════════════════════════════════
        //                    TRI DES COLLECTIONS
        // ═══════════════════════════════════════════════════════════

        titre("TRIS ET CLASSEMENTS");

        sousTitre("Médias triés par année (récent → ancien)");
        List<Media> mediasTriés = new ArrayList<>(medias);
        mediasTriés.sort(Comparator
                .comparingInt(Media::getAnneePublication).reversed()
                .thenComparing(Media::getTitre));
        afficherListe(mediasTriés);

        sousTitre("Livres triés par auteur puis titre");
        List<Livre> livres = medias.stream()
                .filter(m -> m instanceof Livre)
                .map(m -> (Livre) m)
                .sorted(Comparator
                        .comparing(Livre::getAuteur)
                        .thenComparing(Livre::getTitre))
                .collect(Collectors.toList());
        afficherListe(livres);

        // ═══════════════════════════════════════════════════════════
        //                    OPÉRATIONS AVANCÉES
        // ═══════════════════════════════════════════════════════════

        titre("OPÉRATIONS AVANCÉES");

        sousTitre("Copie de Collection");
        List<Media> copieMedias = new ArrayList<>();
        copierCollection(medias, copieMedias);
        System.out.println("  Copie réussie : " + copieMedias.size() + " éléments");

        sousTitre("Médias Empruntés (sans doublons)");
        Set<Media> mediasEmpruntes = obtenirMediasEmpruntes(emprunts);
        mediasEmpruntes.forEach(m -> System.out.println("  - " + m.getTitre()));

        // ═══════════════════════════════════════════════════════════
        //                    POLYMORPHISME
        // ═══════════════════════════════════════════════════════════

        titre("DÉMONSTRATION DU POLYMORPHISME");

        sousTitre("Affichage détaillé (méthode polymorphe)");
        Arrays.asList(medias.get(0), medias.get(3), medias.get(2))
                .forEach(m -> {
                    separateur();
                    m.afficherDetails();
                });

        sousTitre("Interface Empruntable");
        Livre livre1984 = (Livre) medias.get(0);
        CD cdThriller = (CD) medias.get(3);

        System.out.println("\n  Premier emprunt :");
        livre1984.emprunter();
        cdThriller.emprunter();

        System.out.println("\n  Tentative de double emprunt :");
        livre1984.emprunter();
        cdThriller.emprunter();

        sousTitre("Liste polymorphe d'objets Empruntables");
        List<Empruntable> itemsEmpruntables = Arrays.asList(
                new Livre("Le Seigneur des Anneaux", 1954, "J.R.R. Tolkien", 1200),
                new CD("The Dark Side of the Moon", 1973, "Pink Floyd", 43),
                new Livre("Dune", 1965, "Frank Herbert", 688)
        );

        System.out.println();
        itemsEmpruntables.forEach(Empruntable::emprunter);

        // ═══════════════════════════════════════════════════════════

        System.out.println("\n");
        titre("FIN DU PROGRAMME");
        System.out.println();
    }
}